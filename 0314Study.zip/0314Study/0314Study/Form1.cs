﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0314Study
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private  void SetCheckBox(int gB)//체크박스 체크표시함수
        {
            ck0.Checked = (gB & 0x01 << 0) != 0;
            ck1.Checked = (gB & 0x01 << 1) != 0;
            ck2.Checked = (gB & 0x01 << 2) != 0;
            ck3.Checked = (gB & 0x01 << 3) != 0;
            ck4.Checked = (gB & 0x01 << 4) != 0;
            ck5.Checked = (gB & 0x01 << 5) != 0;
            ck6.Checked = (gB & 0x01 << 6) != 0;
            ck7.Checked = (gB & 0x01 << 7) != 0;
        }

        private void btnToBit_Click(object sender, EventArgs e)
        {
            int gB=Convert.ToInt32(txtNumber.Text);
            //체크박스 체크표시
            SetCheckBox(gB);
        }

        private int GetCheckBox()
        {
            int gB = 0;
            if (ck0.Checked) gB = gB | 0x01;//젤 하위비트만 1로
            if (ck1.Checked) gB = gB | 0x02;
            if (ck2.Checked) gB = gB | 0x04;
            if (ck3.Checked) gB = gB | 0x08;
            if (ck4.Checked) gB = gB | 0x10;
            if (ck5.Checked) gB = gB | 0x20;
            if (ck6.Checked) gB = gB | 0x40;
            if (ck7.Checked) gB = gB | 0x80;
            return gB;
        }
        private void btnFromBit_Click(object sender, EventArgs e)
        {
            int gB=GetCheckBox();
            txtNumber.Text = Convert.ToString(gB);
        }

        private void btnON_Click(object sender, EventArgs e)
        {
            int gB = Convert.ToInt32(txtNumber.Text);
            int idx= Convert.ToInt32(txtIndex.Text);

            gB = gB | (0x01 << idx);//해당숫자 체크하기(무조건 1되게)
            txtNumber.Text = Convert.ToString(gB);//십진수표시

            //체크박스체크표시
            SetCheckBox(gB);
        }

        private void btnOFF_Click(object sender, EventArgs e)
        {
            int gB = Convert.ToInt32(txtNumber.Text);
            int idx = Convert.ToInt32(txtIndex.Text);

            gB = gB & ~(0x01 << idx);//해당숫자 체크해제(무조건 0되게)
            txtNumber.Text = Convert.ToString(gB);//십진수표시

            //체크박스체크표시
            SetCheckBox(gB);
        }
    }
}
//>>, <<, ON, OFF까지함
//Toggle, ShiftUp, ShiftDown내가 해야함