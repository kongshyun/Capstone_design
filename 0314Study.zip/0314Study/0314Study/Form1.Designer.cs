﻿namespace _0314Study
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.txtIndex = new System.Windows.Forms.TextBox();
            this.btnToBit = new System.Windows.Forms.Button();
            this.btnFromBit = new System.Windows.Forms.Button();
            this.btnON = new System.Windows.Forms.Button();
            this.btnOFF = new System.Windows.Forms.Button();
            this.btnToggle = new System.Windows.Forms.Button();
            this.btnShiftUp = new System.Windows.Forms.Button();
            this.btnShiftDown = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ck7 = new System.Windows.Forms.CheckBox();
            this.ck6 = new System.Windows.Forms.CheckBox();
            this.ck4 = new System.Windows.Forms.CheckBox();
            this.ck5 = new System.Windows.Forms.CheckBox();
            this.ck2 = new System.Windows.Forms.CheckBox();
            this.ck3 = new System.Windows.Forms.CheckBox();
            this.ck0 = new System.Windows.Forms.CheckBox();
            this.ck1 = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNumber
            // 
            this.txtNumber.Location = new System.Drawing.Point(30, 31);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(116, 21);
            this.txtNumber.TabIndex = 0;
            this.txtNumber.Text = "45";
            // 
            // txtIndex
            // 
            this.txtIndex.Location = new System.Drawing.Point(30, 191);
            this.txtIndex.Name = "txtIndex";
            this.txtIndex.Size = new System.Drawing.Size(116, 21);
            this.txtIndex.TabIndex = 1;
            this.txtIndex.Text = "3";
            // 
            // btnToBit
            // 
            this.btnToBit.Location = new System.Drawing.Point(198, 31);
            this.btnToBit.Name = "btnToBit";
            this.btnToBit.Size = new System.Drawing.Size(99, 44);
            this.btnToBit.TabIndex = 2;
            this.btnToBit.Text = ">>";
            this.btnToBit.UseVisualStyleBackColor = true;
            this.btnToBit.Click += new System.EventHandler(this.btnToBit_Click);
            // 
            // btnFromBit
            // 
            this.btnFromBit.Location = new System.Drawing.Point(198, 81);
            this.btnFromBit.Name = "btnFromBit";
            this.btnFromBit.Size = new System.Drawing.Size(99, 44);
            this.btnFromBit.TabIndex = 3;
            this.btnFromBit.Text = "<<";
            this.btnFromBit.UseVisualStyleBackColor = true;
            this.btnFromBit.Click += new System.EventHandler(this.btnFromBit_Click);
            // 
            // btnON
            // 
            this.btnON.Location = new System.Drawing.Point(198, 191);
            this.btnON.Name = "btnON";
            this.btnON.Size = new System.Drawing.Size(99, 44);
            this.btnON.TabIndex = 4;
            this.btnON.Text = "ON";
            this.btnON.UseVisualStyleBackColor = true;
            this.btnON.Click += new System.EventHandler(this.btnON_Click);
            // 
            // btnOFF
            // 
            this.btnOFF.Location = new System.Drawing.Point(198, 241);
            this.btnOFF.Name = "btnOFF";
            this.btnOFF.Size = new System.Drawing.Size(99, 44);
            this.btnOFF.TabIndex = 5;
            this.btnOFF.Text = "OFF";
            this.btnOFF.UseVisualStyleBackColor = true;
            this.btnOFF.Click += new System.EventHandler(this.btnOFF_Click);
            // 
            // btnToggle
            // 
            this.btnToggle.Location = new System.Drawing.Point(198, 291);
            this.btnToggle.Name = "btnToggle";
            this.btnToggle.Size = new System.Drawing.Size(99, 44);
            this.btnToggle.TabIndex = 6;
            this.btnToggle.Text = "Toggle";
            this.btnToggle.UseVisualStyleBackColor = true;
            // 
            // btnShiftUp
            // 
            this.btnShiftUp.Location = new System.Drawing.Point(31, 392);
            this.btnShiftUp.Name = "btnShiftUp";
            this.btnShiftUp.Size = new System.Drawing.Size(130, 44);
            this.btnShiftUp.TabIndex = 7;
            this.btnShiftUp.Text = "ShiftUp";
            this.btnShiftUp.UseVisualStyleBackColor = true;
            // 
            // btnShiftDown
            // 
            this.btnShiftDown.Location = new System.Drawing.Point(167, 392);
            this.btnShiftDown.Name = "btnShiftDown";
            this.btnShiftDown.Size = new System.Drawing.Size(130, 44);
            this.btnShiftDown.TabIndex = 8;
            this.btnShiftDown.Text = "ShiftDown";
            this.btnShiftDown.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(363, 46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(104, 390);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(361, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 12);
            this.label1.TabIndex = 10;
            this.label1.Text = "BITS";
            // 
            // ck7
            // 
            this.ck7.AutoSize = true;
            this.ck7.Location = new System.Drawing.Point(410, 68);
            this.ck7.Name = "ck7";
            this.ck7.Size = new System.Drawing.Size(30, 16);
            this.ck7.TabIndex = 11;
            this.ck7.Text = "7";
            this.ck7.UseVisualStyleBackColor = true;
            // 
            // ck6
            // 
            this.ck6.AutoSize = true;
            this.ck6.Location = new System.Drawing.Point(410, 109);
            this.ck6.Name = "ck6";
            this.ck6.Size = new System.Drawing.Size(30, 16);
            this.ck6.TabIndex = 12;
            this.ck6.Text = "6";
            this.ck6.UseVisualStyleBackColor = true;
            // 
            // ck4
            // 
            this.ck4.AutoSize = true;
            this.ck4.Location = new System.Drawing.Point(410, 206);
            this.ck4.Name = "ck4";
            this.ck4.Size = new System.Drawing.Size(30, 16);
            this.ck4.TabIndex = 14;
            this.ck4.Text = "4";
            this.ck4.UseVisualStyleBackColor = true;
            // 
            // ck5
            // 
            this.ck5.AutoSize = true;
            this.ck5.Location = new System.Drawing.Point(410, 161);
            this.ck5.Name = "ck5";
            this.ck5.Size = new System.Drawing.Size(30, 16);
            this.ck5.TabIndex = 13;
            this.ck5.Text = "5";
            this.ck5.UseVisualStyleBackColor = true;
            // 
            // ck2
            // 
            this.ck2.AutoSize = true;
            this.ck2.Location = new System.Drawing.Point(410, 306);
            this.ck2.Name = "ck2";
            this.ck2.Size = new System.Drawing.Size(30, 16);
            this.ck2.TabIndex = 16;
            this.ck2.Text = "2";
            this.ck2.UseVisualStyleBackColor = true;
            // 
            // ck3
            // 
            this.ck3.AutoSize = true;
            this.ck3.Location = new System.Drawing.Point(410, 256);
            this.ck3.Name = "ck3";
            this.ck3.Size = new System.Drawing.Size(30, 16);
            this.ck3.TabIndex = 15;
            this.ck3.Text = "3";
            this.ck3.UseVisualStyleBackColor = true;
            // 
            // ck0
            // 
            this.ck0.AutoSize = true;
            this.ck0.Location = new System.Drawing.Point(410, 407);
            this.ck0.Name = "ck0";
            this.ck0.Size = new System.Drawing.Size(30, 16);
            this.ck0.TabIndex = 18;
            this.ck0.Text = "0";
            this.ck0.UseVisualStyleBackColor = true;
            // 
            // ck1
            // 
            this.ck1.AutoSize = true;
            this.ck1.Location = new System.Drawing.Point(410, 356);
            this.ck1.Name = "ck1";
            this.ck1.Size = new System.Drawing.Size(30, 16);
            this.ck1.TabIndex = 17;
            this.ck1.Text = "1";
            this.ck1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 471);
            this.Controls.Add(this.ck0);
            this.Controls.Add(this.ck1);
            this.Controls.Add(this.ck2);
            this.Controls.Add(this.ck3);
            this.Controls.Add(this.ck4);
            this.Controls.Add(this.ck5);
            this.Controls.Add(this.ck6);
            this.Controls.Add(this.ck7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnShiftDown);
            this.Controls.Add(this.btnShiftUp);
            this.Controls.Add(this.btnToggle);
            this.Controls.Add(this.btnOFF);
            this.Controls.Add(this.btnON);
            this.Controls.Add(this.btnFromBit);
            this.Controls.Add(this.btnToBit);
            this.Controls.Add(this.txtIndex);
            this.Controls.Add(this.txtNumber);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.TextBox txtIndex;
        private System.Windows.Forms.Button btnToBit;
        private System.Windows.Forms.Button btnFromBit;
        private System.Windows.Forms.Button btnON;
        private System.Windows.Forms.Button btnOFF;
        private System.Windows.Forms.Button btnToggle;
        private System.Windows.Forms.Button btnShiftUp;
        private System.Windows.Forms.Button btnShiftDown;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox ck7;
        private System.Windows.Forms.CheckBox ck6;
        private System.Windows.Forms.CheckBox ck4;
        private System.Windows.Forms.CheckBox ck5;
        private System.Windows.Forms.CheckBox ck2;
        private System.Windows.Forms.CheckBox ck3;
        private System.Windows.Forms.CheckBox ck0;
        private System.Windows.Forms.CheckBox ck1;
    }
}

